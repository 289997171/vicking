﻿using UnityEngine;

public class Clazz2 : Clazz
{
    public override void sayHello()
    {
        Debug.Log("Clazz2");
    }
}
