﻿using UnityEngine;

public class Clazz1 : Clazz
{
    public override void sayHello()
    {
        Debug.Log("Clazz1");
    }
}
