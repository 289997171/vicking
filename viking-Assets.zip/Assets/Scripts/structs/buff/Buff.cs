﻿public class Buff
{

}
