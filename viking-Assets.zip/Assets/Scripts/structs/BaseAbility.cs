﻿public class BaseAbility
{
    //移动速度
    public float speed;
}
