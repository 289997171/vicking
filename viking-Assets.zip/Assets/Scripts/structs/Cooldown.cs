﻿
public class Cooldown
{

}
