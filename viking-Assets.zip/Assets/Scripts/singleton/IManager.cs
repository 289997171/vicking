﻿public interface IManager
{
    /// <summary>
    ///     初始化
    /// </summary>
    /// <returns>初始化是否成功</returns>
    bool Init();
}
