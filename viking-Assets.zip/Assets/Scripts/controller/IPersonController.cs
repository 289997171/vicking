﻿public interface IPersonController
{
    /// <summary>
    /// 初始化
    /// </summary>
    /// <param name="person"></param>
    void updated();

}
