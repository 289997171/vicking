﻿using UnityEngine;

public abstract class FigtAnimationController : MonoBehaviour
{

    public abstract void castSkill(int skillId, int skillLv);
}
