﻿using UnityEngine;

public class PlayerAreaController : AreaController
{
    public override void OnMove(Vector3 oldPos, Vector3 newPos)
    {
    }
}
